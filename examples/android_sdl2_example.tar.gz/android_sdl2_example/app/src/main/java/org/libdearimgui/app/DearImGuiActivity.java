package org.libdearimgui.app;

import org.libsdl.app.SDLActivity;

public class DearImGuiActivity extends SDLActivity {
    
}